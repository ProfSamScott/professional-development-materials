/**
 * Example program showing input, processing, and output. October 22, 2009.
 * 
 * @author Sam Scott
 **/

package ExampleCode; 

import hsa_ufa.Console; 
import java.awt.*;      

public class ChildAgeCalculator2
{   
  /**
   * The Main Method
   **/
  public static void main (String[] args) throws InterruptedException
  {
    Console c = new Console ();
    
    // *** variables
    int age;      // user�s age
    int kidsAge;  // user�s child�s age
    
    // *** constants
    final int AGE_HAD_CHILD = 20; // age you had the child
    
    // *** input
    c.println("What is your age? ");
    age = c.readInt();
    
    // *** processing
    kidsAge = age - AGE_HAD_CHILD;   // how old would their kid be?
    
    // *** output
    c.println("If you had a child when you were " + AGE_HAD_CHILD + ", he or she would now be " + 
              kidsAge + " years old");
  } 
}
