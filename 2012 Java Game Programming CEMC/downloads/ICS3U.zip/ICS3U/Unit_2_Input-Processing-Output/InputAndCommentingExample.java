/**
 * This program demonstrates how to get input from a console.
 * It also demonstrates how to comment your code.
 *
 * You should always include a header like this one that
 * explains what the program does, and includes your name and
 * the date you created the program. Inside the program itself,
 * you should make headings for sections, such as...
 *
 * *** Variable Declarations
 * *** Input
 * *** Processing
 * *** Output
 *
 * ...and anything else that makes sense.
 *
 * The code should be indented well and variables should be named
 * descriptively and their usage should be explained.
 *
 * By Sam Scott, September 25, 2006. Modified October 1, 2010.
 **/
package ExampleCode;

import java.awt.*;
import hsa_ufa.Console;

public class InputAndCommentingExample
{
  static Console c;           // The output console
  
  public static void main (String[] args)
    throws InterruptedException // required by Thread.sleep()
  {
    // *** Create the console
    c = new Console ();
    
    // *** Variable Declarations
    int age;                // every variable should be explained and/or
    String name;            // named descriptively
    double cashOnHand;
    double incomePerYear;   // holds calculated yearly income
    char continueKey;       // holds user input
    
    // *** Input
    c.println ("What is your name?");   // not much commenting is needed
    name = c.readLine ();               // here, unless something unusual
    c.print ("Enter your age: ");       // is going on.
    age = c.readInt ();
    c.print ("How much money do you have on you right now (in dollars)? ");
    cashOnHand = c.readDouble ();
    
    c.println();
    c.println("Press any key to continue.");
    continueKey = c.getChar();
    c.println();
    c.println("You pressed: '"+continueKey+"' (in case you were wondering)");
    Thread.sleep(1000);
    
    // *** Processing
    incomePerYear = cashOnHand / age;   // calculate income per year
    name = "The great and wonderful " + name;  // add a title to the name
    
    // *** Output
    c.clear ();                     // commenting in this part
    c.print ("Announcing... ");     // doesn't need to be too
    Thread.sleep (1000);            // detailed, because it's just
    c.setColor (Color.RED);     // output and it's pretty self-
    c.print ("\t" + name + "...");  // explanatory
    c.println ();
    c.println ();
    c.setColor (Color.BLACK);
    Thread.sleep (2000);
    c.println ("                has earned");
    c.println ();
    Thread.sleep (500);
    c.print (" ...on average");
    Thread.sleep (500);
    c.print (" ...the handsome sum");
    Thread.sleep (1500);
    c.println (" ...of");
    c.println ();
    Thread.sleep (2000);
    c.print ("        ");
    c.setColor (Color.WHITE);
    c.setBackgroundColor (Color.BLACK);
    c.print ("$");
    c.print (incomePerYear, 4, 2);
    c.setColor (Color.BLACK);
    c.setBackgroundColor (Color.WHITE);
    c.println ();
    c.println ();
    Thread.sleep (2000);
    c.println ("        per year.");
    c.println ();
    c.println ();
    Thread.sleep (2000);
    c.println ("        since birth.");
    c.println ();
    c.println ();
    Thread.sleep (5000);
    c.println ("Thank you very much.");
    Thread.sleep (1000);
    c.close();
      
  } // main method
} // InputExample class
