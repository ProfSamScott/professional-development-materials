/**
 * Example program showing input, processing, and output. October 22, 2009.
 * 
 * @author Sam Scott
 **/

package ExampleCode; 

import hsa_ufa.Console; 
import java.awt.*;      

public class ChildAgeCalculator
{   
  public static void main (String[] args) throws InterruptedException
  {
    Console c = new Console ();
    
    // *** variables
    int age;      // user�s age
    int kidsAge;  // user�s child�s age
    
    // *** input
    c.println("What is your age? ");
    age = c.readInt();
    
    // *** processing
    kidsAge = age - 20;   // how old would their kid be?
    
    // *** output
    c.println("If you had a child when you were 20, he or she would now be " + kidsAge + " years old");
  } 
}
