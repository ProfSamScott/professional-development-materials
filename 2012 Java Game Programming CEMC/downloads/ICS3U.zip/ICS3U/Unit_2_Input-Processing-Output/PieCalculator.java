/**
 * This program is supposed to tell me how much pie I get, but it always tells me I'm
 * getting 0 square centimeters. No fair! Help me fix it with the Dr. Java debugger.
 * December 5, 2009.
 * 
 * @author Sam Scott
 **/

package ExampleCode; 

import hsa_ufa.Console; 
import java.awt.*;      

public class PieCalculator
{   
    public static void main (String[] args) throws InterruptedException
    {
        Console c = new Console ();

        // *** variables
        int percentOfPie; // user input
        double fractionOfPie; // percent of pie as a decimal
        double pieArea;       // area of the pie I'm getting

        // *** input
        c.println("I have a pie that is 500 square centimetres in area.\nWhat percentage of the pie do you want?");
        percentOfPie = c.readInt();
        
        // *** processing
        fractionOfPie = percentOfPie / 100;   // Convert the percent to a decimal
        pieArea = 500 * fractionOfPie;        // Get the area of the pie
        
        // *** output
        c.print("The area of your piece of pie will be ");
        c.print(pieArea,1,1);
        c.println(" square centimeters. Yum.");
    } 
}
