/**
 * Demonstrates how to accept Arrays as parameters and how to 
 * return Arrays. April 19, 2011.
 * 
 * @author Sam Scott
 **/

package ExampleCode;  

import hsa_ufa.Console;
import java.awt.*;     

public class ArrayMethods // change this to match the name of the file
{
  static Console c = new Console(); // You can change this line to make the console bigger or smaller
  
  /**
   * Prints a list of doubles
   * 
   * @param list 
   *             An array of doubles
   */
  public static void printList(double[] list)
  {
    for (int i=0; i<list.length; i++)
    {
      c.print(i,3);
      c.print(": ");
      c.println(list[i],10,5);
    }
  }
  
  /**
   * Generates a geometric progression given a and r. A geometric progression
   * is a list of terms of the form a*r^i, where i is an integer starting
   * at zero. http://en.wikipedia.org/wiki/Geometric_progression
   * 
   * @param a
   *          The a value for the progression
   * @param r 
   *          The r value for the progression
   * @param length
   *          The length of the progression to generate
   * @return
   *          A double array of the series
   **/
  public static double[] geometricProgression(double a, double r, int length)
  {
    double[] progression = new double[length];
    
    for (int i=0; i<length; i++)
      progression[i] = a*Math.pow(r,i);
    
    return progression;
  }
  
  /**
   * Main method to test the above methods
   * 
   * @param args unused
   **/
  public static void main(String[] args)
  {
    c.println("Enter a and r for a geometric progression.");
    double a = c.readDouble();
    double r = c.readDouble();
    
    c.println("How many numbers should I generate?");
    int n = c.readInt();
    
    double[] numbers = geometricProgression(a, r, n);
    printList(numbers);
  }
}