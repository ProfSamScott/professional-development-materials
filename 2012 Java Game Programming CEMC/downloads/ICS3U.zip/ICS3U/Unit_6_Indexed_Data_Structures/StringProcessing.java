/**
 * A couple of examples of how to process a String. April 20, 2011.
 * 
 * @author Sam Scott
 **/

package ExampleCode; 

import hsa_ufa.Console; 
import java.awt.*;      

public class StringProcessing 
{
  static Console c = new Console(); 
  
  /**
   * What does this mysterious method do?
   * @param s
   **/
  public static int foo(String s)
  {
    int counter = 0;
    int i=0;
    while (i<s.length())
    {
      if (s.charAt(i) == 'a' || s.charAt(i) == 'b')
        counter = counter + 1;
      i = i + 1;
    }
    return counter;
  }

   /**
   * What does this mysterious method do?
   * @param s
   **/
  public static String foobar(String s)
  {
    String t = "";
    for (int i=0; i<s.length(); i++)
    {
      if (s.charAt(i) == 'a' | s.charAt(i) == 'b')
        t = t + "_";
      else
        t = t + s.charAt(i);
    }
    s = t;
    return (s);
  }
  
  /**
   * Convenience method to get the user to hit any key.
   * @return the key the user pressed (just in case we need it for something)
   **/
  public static char hitAnyKey()
  {
    char input;
    c.println("\nHit any key.");
    if ((input = c.getChar()) == 'e')
      System.out.println("You Found the Easter Egg!");
    return input;
    
  }
  
  /**
   * This method prints out my highly stylish signature
   **/
  public static void printSignature () throws InterruptedException
  {
    c.clear ();
    c.println ();
    c.println (" \t\t***********************************");
    c.println (" \t\t*  ANOTHER TRIUMPH OF CODING BY   *");
    c.println (" \t\t*                                 *");
    c.println (" \t\t*            Sam Scott            *");
    c.println (" \t\t***********************************");
    c.println ();
    c.println ();
    for (int i = 0 ; i < 5 ; i++)
    {
      c.setColor (Color.RED);
      c.fillStar (10, 10, 100, 100);
      c.fillStar (380, 10, 100, 100);
      Thread.sleep (500);
      c.setColor (Color.WHITE);
      c.fillStar (10, 10, 100, 100);
      c.fillStar (380, 10, 100, 100);
      Thread.sleep (500);
    }
    c.setColor(Color.black);
    
    c.clear ();
  }
  
  public static void main(String[] args) throws InterruptedException
  {   
    printSignature();
    c.println("Enter a string: ");
    String s = c.readLine();
    c.println();
    c.println("Here's what I get when I call s.toUpperCase(): \n        "+s.toUpperCase());
    hitAnyKey();
    c.println("\nBut notice the original string is unchanged: \n        "+s);
    hitAnyKey();
    c.println("\nHere's what foo(s) returns: \n        "+foo(s));
    hitAnyKey();
    s = foobar(s);
    c.println("\nNow I have executed s=foobar(s), and here's what s looks like now:\n        "+s);
    hitAnyKey();
    System.out.println("Goodbye!");
    c.close();
  }
}