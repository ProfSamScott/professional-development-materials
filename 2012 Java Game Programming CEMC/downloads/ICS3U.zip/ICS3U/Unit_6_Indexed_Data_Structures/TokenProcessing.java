/**
 * A couple of examples of how to process a String one token at
 * a time. April 20, 2011.
 * 
 * @author Sam Scott
 **/

package ExampleCode; 

import hsa_ufa.Console; 
import java.awt.*;      
import java.util.StringTokenizer;
  
public class TokenProcessing 
{
  static Console c = new Console(); 
  
  /**
   * What does this mysterious method do?
   * @param s
   **/
  public static int foo(String inString)
  {
    int counter = 0;
    StringTokenizer st = new StringTokenizer(inString); 
    while (st.hasMoreTokens())        
    {
      if (st.nextToken().equalsIgnoreCase("sam"))
        counter = counter + 1;
    }
    return counter;
  }
  
  
  /**
   * What does this mysterious method do?
   * @param s
   **/
  public static String foobar(String t)
  {
    String newString = "";
    StringTokenizer st = new StringTokenizer(t, " .,\t!?\n"); 
    while (st.hasMoreTokens())        
    {
      String token = st.nextToken();
       newString = token + " "+ newString;
    }
    return newString;
  }
  
  
  /**
   * Convenience method to get the user to hit any key.
   * @return the key the user pressed (just in case we need it for something)
   **/
  public static char hitAnyKey()
  {
    char input;
    c.println("\nHit any key.");
    if ((input = c.getChar()) == 'e')
      System.out.println("You Found the Easter Egg!");
    return input;
    
  }
  
  /**
   * This method prints out my highly stylish signature
   **/
  public static void printSignature () throws InterruptedException
  {
    c.clear ();
    c.println ();
    c.println (" \t\t***********************************");
    c.println (" \t\t*  ANOTHER TRIUMPH OF CODING BY   *");
    c.println (" \t\t*                                 *");
    c.println (" \t\t*            Sam Scott            *");
    c.println (" \t\t***********************************");
    c.println ();
    c.println ();
    for (int i = 0 ; i < 5 ; i++)
    {
      c.setColor (Color.RED);
      c.fillStar (10, 10, 100, 100);
      c.fillStar (380, 10, 100, 100);
      Thread.sleep (500);
      c.setColor (Color.WHITE);
      c.fillStar (10, 10, 100, 100);
      c.fillStar (380, 10, 100, 100);
      Thread.sleep (500);
    }
    c.setColor(Color.black);
    
    c.clear ();
  }
  
  public static void main(String[] args) throws InterruptedException
  {   
    printSignature();
    c.println("Enter a string: ");
    String s = c.readLine();
    c.println();
    c.println("Here's what I get when I call foo(s): \n        "+foo(s));
    hitAnyKey();
    c.println("\nHere's what I get when I call foobar(s) \n        "+foobar(s));
    hitAnyKey();
    System.out.println("Goodbye!");
    c.close();
  }
}