/**
 * An example using a method to add two numbers. Also
 * shows an example of proper commenting.
 * 
 * @author Sam Scott
 **/

package ExampleCode; 

import hsa_ufa.Console; 
import java.awt.*;      

public class ReturnValuesExample 
{
  static Console c = new Console(200,100); 
  
  /**
   * Adds two numbers
   * @param num1
   *             the first number
   * @param num2
   *             the second number
   * @return num1+num2
   **/
  public static double add(double num1, double num2)
  {
    return num1+num2;
  }
  
  /**
   * Tests the add method.
   * @param args
   *             unused
   **/
  public static void main(String[] args)
  {
    c.println("Enter two numbers");
    double firstNum = c.readDouble();
    double secondNum = c.readDouble();
    c.println(firstNum+" + "+secondNum+" = "+add(firstNum,secondNum));
  }
}