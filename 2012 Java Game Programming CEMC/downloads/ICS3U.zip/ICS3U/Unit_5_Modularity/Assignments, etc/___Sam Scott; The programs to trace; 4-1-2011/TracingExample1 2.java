// EXERCISE:
// Trace this program assuming the user enters 5 and 7
// Try again for -3 and -6
package ExampleCode;

import java.awt.*;
import hsa_ufa.Console;

public class TracingExample1
{
  static Console c;           // The output console
  
  public static void main (String[] args)
  {
    c = new Console ();
    
    int p;
    double q;
    
    c.println ("Enter an integer");
    p = c.readInt ();
    c.println ("Enter a double");
    q = c.readDouble ();
    q = foo (p, q, "Aargh");
    q = q + p;
    c.println (q);
  } // main method
  
  
  public static double foo (int x, double y, String z)
  {
    double r = x + y;
    if (x > y)
      c.println (z);
    else
      c.println ("whoops");
    return r;
  }
} // TracingExample1 class
