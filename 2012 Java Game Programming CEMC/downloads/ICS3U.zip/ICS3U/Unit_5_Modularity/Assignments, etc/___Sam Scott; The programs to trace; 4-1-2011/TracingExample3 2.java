// EXERCISE:
// Trace this program assuming the user enters 2 and 2 and 5
// Try again for 2 and -4 and -2
// Can you find the logic errors and fix them?
package ExampleCode;

import java.awt.*;
import hsa_ufa.Console;

public class TracingExample3
{
  static Console c;           // The output console
  
  public static void main (String[] args)
  {
    c = new Console ();
    
    int x, y, z;
    boolean answerCheck;
    
    c.println ("Enter two integers");
    x = c.readInt ();
    y = c.readInt ();
    c.println ("What is their sum?");
    z = c.readInt ();
    c.println ();
    c.println (x + " + " + y + " = " + z + "?");
    if (addUp (x, y) == z)
      c.println ("Right!");
    else
      c.println ("Stay in school, kid.");
      c.println ("You got that wrong, but here's the right answer");
      c.println (x + " + " + y + " = " + z + "!");
  } // main method
  
  public static int addUp (int x, int y)
  {
    return x+y;
  }
} 
