// EXERCISE:
// Trace this program assuming the user enters 2 and 5
// Try again for 3 and 0
package ExampleCode;

import java.awt.*;
import hsa_ufa.Console;

public class TracingExample2
{
  static Console c;           // The output console
  
  public static void main (String[] args)
  {
    c = new Console ();
    
    int x, q;
    
    c.println ("Enter two integers");
    x = c.readInt ();
    q = c.readInt ();
    c.println(cool (x, q));
    c.println (x);
  } // main method
  
  
  public static int cool (int x, int y)
  {
    int result = 0;
    while (x < y)
    {
      result = x * y;
      x = x + 1;
    }
    return result;
  }
} // TracingExample1 class
