/**
 * The "Day1Example1" class - Sample code for Day 1 of
 * the ICS3M Modularity unit. Created January 14, 2006
 *
 * @Author Sam Scott
 **/

package ExampleCode;

import java.awt.Color;
import hsa_ufa.Console;

public class MP3_Not_Modular
{
  static Console c;           // The output console
  
  public static void main (String[] args) throws InterruptedException
  {
    c = new Console ();
    
    // variables
    int ratingOfSong = 0, qualityOfEncoding = 0; // hold user input
    double rating; // holds the rating of the mp3 file
    String filename; // holds the name of the mp3 file
    
    // print signature
    c.clear ();
    c.println ();
    c.println (" \t\t***********************************");
    c.println (" \t\t*  ANOTHER TRIUMPH OF CODING BY   *");
    c.println (" \t\t*                                 *");
    c.println (" \t\t*            Sam Scott            *");
    c.println (" \t\t***********************************");
    c.println ();
    c.println ();
    for (int i = 0 ; i < 5 ; i++)
    {
      c.setColor (Color.RED);
      c.fillStar (10, 10, 100, 100);
      c.fillStar (430, 10, 100, 100);
      Thread.sleep (500);
      c.setColor (Color.WHITE);
      c.fillStar (10, 10, 100, 100);
      c.fillStar (430, 10, 100, 100);
      Thread.sleep (500);
    }
    c.clear ();
    
    // print a header
    c.setColor(Color.black);
    c.println ("This program will compute a rating for an mp3 file.");
    c.println ();
    
    // get the file name
    c.print ("Please enter the name of the mp3 file: ");
    filename = c.readLine ();
    
    // get the song rating
    c.print ("Enter a rating for the song in " + filename + " (1-10): ");
    do
    {
      ratingOfSong = c.readInt ();
      if (ratingOfSong < 1 || ratingOfSong > 10)
        c.println (" \t*** Error. Number must be in range 1..10. Please try again.");
    }
    while (ratingOfSong < 1 || ratingOfSong > 10);
    
    // get the MP3 quality rating
    c.print ("Enter a rating for mp3 quality of " + filename + " (1-10): ");
    do
    {
      qualityOfEncoding = c.readInt ();
      if (qualityOfEncoding < 1 || qualityOfEncoding > 10)
        c.println ("\t*** Error. Number must be in range 1..10. Please try again.");
    }
    while (qualityOfEncoding < 1 || qualityOfEncoding > 10);
    
    // compute and display the overall mp3 rating
    rating = (ratingOfSong + qualityOfEncoding) / 2.0;
    c.println ();
    c.println (filename + " has an overall rating of: " + rating);
    Thread.sleep (5000);
    
    // print signature
    c.clear ();
    c.println ();
    c.println (" \t\t***********************************");
    c.println (" \t\t*  ANOTHER TRIUMPH OF CODING BY   *");
    c.println (" \t\t*                                 *");
    c.println (" \t\t*            Sam Scott            *");
    c.println (" \t\t***********************************");
    c.println ();
    c.println ();
    for (int i = 0 ; i < 5 ; i++)
    {
      c.setColor (Color.RED);
      c.fillStar (10, 10, 100, 100);
      c.fillStar (430, 10, 100, 100);
      Thread.sleep (500);
      c.setColor (Color.WHITE);
      c.fillStar (10, 10, 100, 100);
      c.fillStar (430, 10, 100, 100);
      Thread.sleep (500);
    }
    c.clear ();
    
  } // main method
} // Day1Prog1 class


