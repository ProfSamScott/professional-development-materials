/**
 * The "Day1Example2" class - Sample code for Day 1 of
 * the ICS3M Modularity unit. Created January 14, 2006
 *
 * @Author Sam Scott
 **/

package ExampleCode;

import java.awt.Color;
import hsa_ufa.Console;


public class MP3_Modularized
{
  static Console c;           // The output console
  
  public static void main (String[] args) throws InterruptedException
  {
    c = new Console ();
    
    // variables
    int ratingOfSong = 0, qualityOfEncoding = 0; // hold user input
    double rating; // holds the rating of the mp3 file
    String filename; // holds the name of the mp3 file
    
    printSignature ();
    
    // print a header
    c.println ("This program will compute a rating for an mp3 file.");
    c.println ();
    
    // get the file name
    c.print ("Please enter the name of the mp3 file: ");
    filename = c.readLine ();
    
    // get the song and MP3 rating
    c.print ("Enter a rating for the song in " + filename + " (1-10): ");
    ratingOfSong = getInteger (1, 10);
    c.print ("Enter a rating for mp3 quality of " + filename + " (1-10): ");
    qualityOfEncoding = getInteger (1, 10);
    
    // compute and display the overall mp3 rating
    computeMP3Rating (filename, ratingOfSong, qualityOfEncoding);
    Thread.sleep (5000);
    
    printSignature ();
    
  } // main method
  
  
  /**
   * This method prints out my highly stylish signature
   **/
  public static void printSignature () throws InterruptedException
  {
    c.clear ();
    c.println ();
    c.println (" \t\t***********************************");
    c.println (" \t\t*  ANOTHER TRIUMPH OF CODING BY   *");
    c.println (" \t\t*                                 *");
    c.println (" \t\t*            Sam Scott            *");
    c.println (" \t\t***********************************");
    c.println ();
    c.println ();
    for (int i = 0 ; i < 5 ; i++)
    {
      c.setColor (Color.RED);
      c.fillStar (10, 10, 100, 100);
      c.fillStar (430, 10, 100, 100);
      Thread.sleep (500);
      c.setColor (Color.WHITE);
      c.fillStar (10, 10, 100, 100);
      c.fillStar (430, 10, 100, 100);
      Thread.sleep (500);
    }
    c.setColor(Color.black);
    
    c.clear ();
  }
  
  
  /**
   * This method computes the rating for an mp3 file.
   * Output - the mp3 file rating.
   *
   * @param name The name of the mp3 file
   * @param song The rating of song quality
   * @param encoding The rating of mp3 encoding quality
   **/
  public static void computeMP3Rating (String name, int song, int encoding)
  {
    // compute rating
    double rating = (song + encoding) / 2.0;
    // output rating
    c.println ();
    c.println (name + " has an overall rating of: " + rating);
  }
  
  
  /**
   * Gets an integer from the user, ensuring that it is within a given range.
   * Return - the integer entered by the user.
   *
   * @param minimum The smallest possible value
   * @param maximum The largest possible value
   **/
  public static int getInteger (int minimum, int maximum)
  {
    int userInput; // holds user input
    
    do
    {
      userInput = c.readInt ();
      if (userInput < minimum || userInput > maximum)
        c.println (" \t*** Error. Number must be in range " + minimum + ".." + maximum + ". Please try again.");
    }
    while (userInput < minimum || userInput > maximum);
    
    return userInput; // return the input to the main program.
  }
} // Day1Prog1 class


