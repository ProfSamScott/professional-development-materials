/**
 * This program shows an example of how to use For loops for
 * repeating a block of code a fixed number of times. November 6, 2006.
 * Updated January 19, 2010.
 *
 * @author Sam Scott
 **/
package ExampleCode;

import java.awt.*;
import hsa_ufa.Console;

public class ForLoop1
{
  static Console c;           // The output console
  
  public static void main (String[] args)
  {
    c = new Console ();
    
    // This loop just counts up to 10
    for (int counter = 1 ; counter <= 10 ; counter++)
    {
      c.println ("This is loop number " + counter);
    }
    
    c.println ("Done");
  } // main method
} // TestIfStatement class