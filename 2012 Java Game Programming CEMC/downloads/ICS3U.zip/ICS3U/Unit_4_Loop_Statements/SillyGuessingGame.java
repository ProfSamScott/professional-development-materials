/**
 * This is a silly little guessing game program. But there's something
 * wrong with it. Can you figure it out? January 12, 2010.
 * 
 * @author Sam Scott
 **/

package ExampleCode; 

import hsa_ufa.Console; 
import java.awt.*;      

public class SillyGuessingGame 
{
  static Console c = new Console(); 
  
  public static void main(String[] args) throws InterruptedException
  {
    // *** variables
    int number; // stores the user's number
    char ynAnswer;    // stores the user's answer to y/n questions
    
    // *** get the number
    c.println("Enter a number from 1 to 10 and I will try to guess it (no decimals).");
    c.println("Don't even think about entering an invalid number. You will be caught!");
    number = c.readInt();
    
    while (number <=1 || number >= 10) // make sure they chose a number from 1 to 10
    {
      c.println("Silly rabbit! I said from 1 to 10. Please try again.");
      number = c.readInt();
    }
    
    // *** pretend to think about it
    c.clear();
    c.println("OK, I'm thinking about it...");
    Thread.sleep(3000);
    c.println("Got it! (Hit any key.)");
    c.getChar();
    
    // *** "guess" the number
    c.clear();
    c.println("Was the number you chose "+number+"? (y/n)");
    ynAnswer = c.getChar();
    
    while (ynAnswer != 'y' && ynAnswer != 'n') // make sure they entered y or n
    {
      c.println("Yeah, yeah. Just answer the question, genius.");
      ynAnswer = c.getChar(); 
    }
    
    // *** respond to the user's answer
    if (ynAnswer == 'n')
      c.println ("You're lying! Everyone always picks "+number+"!");
    else
      c.println ("I can't believe I got that right! I'm a psychic.");
  }
}