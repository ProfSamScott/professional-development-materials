/**
 * An example of the Greedy design pattern in action, using a while statement.
 * 
 * @author Sam Scott
 **/

package ExampleCode; 

import hsa_ufa.Console; 
import java.awt.*;      

public class Greedy 
{
  static Console c = new Console(); 
  
  public static void main(String[] args) throws InterruptedException
  {
    
    c.println("Enter the times for your 10 runs in seconds.");
    
    double bestSoFar = 100000000; // bestSoFar = Worst Possible (or close)
    
    double nextTime;              // var for user input
    int counter = 1;              // loop var
    
    while (counter <= 10)         // loop to 10 numbers
    {
      nextTime = c.readDouble();  // get next value
      if (nextTime < bestSoFar)   // is value better than best so far?
      {
        bestSoFar = nextTime;     // yes it is
      }
      counter = counter + 1;      // change loop variable
    }
    
    // output the result
    c.println();
    c.println("Your fastest run was "+bestSoFar+" s.");
    
  }
}