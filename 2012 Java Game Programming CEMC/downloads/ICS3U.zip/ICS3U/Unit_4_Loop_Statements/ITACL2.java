/**
 * An example of the ITACL design pattern in action, using a while statement.
 * 
 * @author Sam Scott
 **/

package ExampleCode; 

import hsa_ufa.Console; 
import java.awt.*;      

public class ITACL2
{
  static Console c = new Console(); 
  
  public static void main(String[] args) throws InterruptedException
  {
    c.println("Keep talking and say quit when you're done.");
    c.println();    
    
    String userSentence = "";              // Initialize
    while (!userSentence.equals("quit"))   // Test
    {
      c.println("Go ahead: ");             // Act
      c.setColor(Color.red);
      userSentence = c.readLine();         // Change (note it's not at the end)
      c.setColor(Color.black);
      c.println("I knew that already.");
      Thread.sleep(500);
    }                                      // Loop
    
    Thread.sleep(1000);
    c.println();
    c.println("I learned nothing from this. Goodbye.");
    Thread.sleep(5000);
    c.close();
  }
}