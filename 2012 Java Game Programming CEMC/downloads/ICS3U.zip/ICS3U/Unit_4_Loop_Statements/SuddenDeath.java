/**
 * An example of the SuddenDeath design pattern in action, using a while statement.
 * 
 * @author Sam Scott
 **/

package ExampleCode; 

import hsa_ufa.Console; 
import java.awt.*;      

public class SuddenDeath 
{
  static Console c = new Console(); 
  
  public static void main(String[] args) throws InterruptedException
  {
    c.println("What is the fastest speed ever recorded in a speed skiing competition? (km/h)");
    
    boolean found = false;         // found flag
    double answer;                 // user's answers
    
    int counter = 1;               // loop variable
    while (!found)                 // "while not found"...
    {
      answer = c.readDouble();     // get next
      if (answer == 251.4)         // is it what we want?
        found = true;
      else
        counter = counter + 1;
    }
    
    
    c.println("Right! 251.4 km/h by Simone Origone. Got it in "+counter+" guesses.");
    
// program continues
    
    
  }
}