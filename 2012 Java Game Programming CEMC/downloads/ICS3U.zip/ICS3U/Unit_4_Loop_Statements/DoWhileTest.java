/**
 * This program is an example of using do...while for input checking.
 * November 26, 2007. Updated January 19, 2010
 *
 * @author Sam Scott
 **/
package ExampleCode;

import java.awt.*;
import hsa_ufa.Console;

public class DoWhileTest
{
  static Console c;
  
  public static void main (String[] args)
  {
    c = new Console ();
    
    int target; // the number to guess
    int guess;  // the user's guess
    
    target = (int) (Math.random () * 10 + 1);
    
    c.println ("Enter a number between 1 and 10: ");
    do
    {
      guess = c.readInt ();
    }
    while (guess < 1 || guess > 10);
    
    if (guess == target)
      c.println ("You got it!");
    else
      c.println ("Nope, I was thinking of " + target);
  }
}
