/**
 * An example of the CountOff design pattern in action, using a while statement.
 * 
 * @author Sam Scott
 **/

package ExampleCode; 

import hsa_ufa.Console; 
import java.awt.*;      

public class CountOff2
{
  static Console c = new Console(); 
  
  public static void main(String[] args) throws InterruptedException
  {
    c.println("How many things do you want to say?");
    int n = c.readInt();
    c.println();    
    
    int counter = 1; 
    while (counter <= n)
    {
      c.println("Go ahead: ");
      c.setColor(Color.red);
      c.readLine();
      c.setColor(Color.black);
      c.println("I knew that already.");
      Thread.sleep(500);
      
      counter = counter + 1;
    } 
    
    Thread.sleep(1000);
    c.println();
    c.println("I learned nothing from this. Goodbye.");
    Thread.sleep(5000);
    c.close();
  }
}