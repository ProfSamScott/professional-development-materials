/**
 * Here's an example program using the ITACL pattern to print out the
 * factors of a number. It's a bit broken, though. It doesn't print the
 * correct set of factors always, plus the output doesn't look very nice.
 * 
 * How can we fix it up?
 * 
 * @author Sam Scott
 **/

package ExampleCode; 

import hsa_ufa.Console; 
import java.awt.*;      

public class Factors 
{
  static Console c = new Console(); 
  
  public static void main(String[] args) throws InterruptedException
  {
    c.print("What number would you like me to factor? ");
    int n = c.readInt();
    
    c.print("Here are the factors for "+n+": ");
    
    int factor = 1;               // INITIALIZE
    while (factor < n)            // TEST
    {
      if (n % factor == 0)        // ACT
        c.println(factor+", ");
      factor = factor + 1;        // CHANGE
    }                             // LOOP
    
    c.println(".");   
  }
}