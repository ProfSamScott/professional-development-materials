/**
 * An example of the ITACL design pattern in action, using a while statement.
 * 
 * @author Sam Scott
 **/

package ExampleCode; 

import hsa_ufa.Console; 
import java.awt.*;      

public class ITACL 
{
  static Console c = new Console(); 
  
  public static void main(String[] args) throws InterruptedException
  {
    int x = 1;                   // Initialize
    
    while (x < 100)              // Test
    {
      
      c.fillRect(x, 50, 10, 10); // Act
      Thread.sleep(10);
      c.clear();
      x = x + 1;                 // Change
    }                            // Loop
  }
}