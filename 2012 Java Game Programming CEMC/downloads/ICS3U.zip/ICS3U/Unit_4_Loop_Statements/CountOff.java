/**
 * An example of the CountOff design pattern in action, using a while statement.
 * 
 * @author Sam Scott
 **/

package ExampleCode; 

import hsa_ufa.Console; 
import java.awt.*;      

public class CountOff 
{
  static Console c = new Console(); 
  
  public static void main(String[] args) throws InterruptedException
  {
    c.println("How many stars?");
    int numStars = c.readInt();
    c.setColor(Color.red);
    
    int counter = 1; 
    while (counter <= numStars)
    {
      c.fillStar(20*counter,50,20,20);
      counter = counter + 1;
    }
    
  }
}