/**
 * An example of the AllOrNothing design pattern in action, using an if statement.
 * 
 * @author Sam Scott
 **/

package ExampleCode; 

import hsa_ufa.Console; 
import java.awt.*;      

public class AllOrNothingExample 
{
  static Console c = new Console(); 
  
  public static void main(String[] args) throws InterruptedException
  {
    c.print("Hi there. Welcome to the store.\nHow much money are you packing? ");
    double money = c.readDouble();
    c.print("\n$");
    c.print(money,1,2);
    c.print("? That's great. How old are you? ");
    int age = c.readInt();
    
    // Here's the AllOrNothing design pattern...
    if (age == 16)
    {
      c.println();
      c.setBackgroundColor(new Color(200,255,200));
      c.println("Hey! You qualify for our special promotion. Congrats!");
      Thread.sleep(5000);
      c.print("Here's ten bucks. ");
      money = money + 10;
      c.print("You now have $");
      c.print(money,1,2);
      c.println(".");
      Thread.sleep(5000);
      c.setBackgroundColor(Color.white);
    }
    
    c.println();
    c.println("So anyway what do you want to buy?");
    Thread.sleep(1000);
    c.println("... etc. etc. program continues...");
    
  }
}