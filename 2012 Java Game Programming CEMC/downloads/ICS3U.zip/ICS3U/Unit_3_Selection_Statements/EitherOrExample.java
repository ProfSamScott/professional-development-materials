/**
 * An example of the EitherOr design pattern in action, using an if...else statement.
 * 
 * @author Sam Scott
 **/

package ExampleCode; 

import hsa_ufa.Console; 
import java.awt.*;      

public class EitherOrExample 
{
  static Console c = new Console(); 
  
  public static void main(String[] args) throws InterruptedException
  {
    c.print("Hi there. Welcome to ServiceOntario - transportation division.\nHow old are you? ");
    int age = c.readInt();
    c.println();
    
    // Here's the EitherOr design pattern...
    if (age < 16)
    {
      c.setBackgroundColor(new Color(255,200,200));
      c.println("Hey! You are too young to drive! Get lost.");
      Thread.sleep(5000);
      c.setBackgroundColor(Color.white);
    }
    else
    {
      c.setBackgroundColor(new Color(200,255,200));
      c.println("Ok, test time. You're driving down the street and an old man jaywalks in front of you.\nWhat should you do? Keep in mind that you are in a hurry and he is breaking the law.");
      c.readLine();
      c.println("You passed!!! Congrats, pick up your G1 on the way out.");
      Thread.sleep(5000);
      c.setBackgroundColor(Color.white);
    }
    
    c.println();
    c.println("End of program");
    
  }
}