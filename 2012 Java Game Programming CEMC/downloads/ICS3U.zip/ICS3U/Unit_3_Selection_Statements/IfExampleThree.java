/**
 * If Statement Example 3. November 8, 2010.
 * 
 * @author Sam Scott
 **/

package ExampleCode; 

import hsa_ufa.Console; 
import java.awt.*;      

public class IfExampleThree
{
  static Console c = new Console(300,100); 
  
  public static void main(String[] args)
  {
    // *** variables
    char userAnswer; // stores the user's answer.
    
    // *** input
    c.println("Press 'c' to continue: ");
    userAnswer = c.getChar();
    
    // *** processing and output
    if (userAnswer == 'c')
      c.println("OK, we can continue.");
    else
      c.println("You didn't follow the instructions.");
    
  }
}