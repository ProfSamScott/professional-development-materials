package ExampleCode;

import java.awt.*;
import hsa_ufa.Console;

public class BadInternalDocumentation
{
    static Console c = new Console();           
    
    public static void main (String[] args) throws InterruptedException
    {
 int a; c.print("Enter your pay: "); a=c.readInt(); 
 if (a>100000) { c.println("You are rich."); Thread.sleep(1000); 
 c.println("You owe lots of taxes"); } else {
 c.println("You are not rich."); Thread.sleep(1000); 
 c.println("Too bad for you.");}
    } 
} 
