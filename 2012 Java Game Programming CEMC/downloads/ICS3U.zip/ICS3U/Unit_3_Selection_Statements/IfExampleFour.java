/**
 * If Statement Example 4, using string comparison. November 20, 2009.
 * 
 * @author Sam Scott
 **/

package ExampleCode; 

import hsa_ufa.Console; 
import java.awt.*;      

public class IfExampleFour
{
  static Console c = new Console(500,300); 
  
  public static void main(String[] args)
  {
    // *** variables
    String name; // stores the user's name
    int age;     // stores the user's age
    int older;   // how much older the user is than the computer
    
    // *** constants
    final int COMPUTER_AGE = 2; // the age of the computer
    
    // *** dialog with the user
    c.print("Hi, what's your name? ");
    name = c.readLine();
    
    if (name.equalsIgnoreCase("sam"))
      c.println("Hey buddy, welcome back!");
    else
      c.println("I don't think I know you.");
    
    c.print("How old are you? ");
    age = c.readInt();
    
    older = age - COMPUTER_AGE;
    
    c.println("Well, " + name + ", you are " + older + " years older than me.");
  }
}