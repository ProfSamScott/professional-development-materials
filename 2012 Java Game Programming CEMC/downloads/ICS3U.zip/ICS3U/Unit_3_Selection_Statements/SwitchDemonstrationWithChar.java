/**
 * This class demonstrates the switch statement. You can use this statement
 * instead of multiple if statements. It's particularly good for when you
 * want to give the user a menu of choices...   December 4, 2007
 * 
 * Updated January 19, 2010. 
 * 
 * Cloned and Modified November 16, 2010 to use char.
 * 
 * @author Sam Scott
 **/
package ExampleCode;

import java.awt.*;
import hsa_ufa.Console;

public class SwitchDemonstrationWithChar
{
  static Console c;           // The output console
  
  /**
   * @param args unused
   **/
  public static void main (String[] args)
  {
    c = new Console ();
    
    char userInput; // variable for user input
    
    // Print the menu and get input
    c.println ("What would you like to do?");
    c.println ("1 = print a gray square");
    c.println ("2 = print a green circle");
    c.println ("3 = print a blue star");
    c.println ("4 = print a magenta maple leaf");
    userInput = c.getChar ();
    
    // Decide what to do based on the user input
    
    switch (userInput) // this specifies the variable you are using
    {
      case '1':  // if userInput == 1, go here
        c.setColor (Color.gray);
        c.drawRect (200, 200, 100, 100);
        break; // you MUST remember the break statement
      case '2':
        c.setColor(Color.green);
        c.drawOval (200, 200, 100, 100);
        break;
      case '3':
        c.setColor(Color.blue);
        c.drawStar (200, 200, 100, 100);
        break;
      case '4':
        c.setColor(Color.magenta);
        c.drawMapleLeaf (200, 200, 100, 100);
        break;
      default: // if the user entered something else, go here
        // THE DEFAULT PART IS OPTIONAL
        c.setColor (Color.red);
        c.setFont (new Font ("SansSerif", Font.BOLD, 16));
        c.drawString ("You didn't follow the instructions!", 200, 200);
        break;
    }
    c.setColor(Color.black);
    c.drawString("Bye bye!",0, 350);
  } 
} 
