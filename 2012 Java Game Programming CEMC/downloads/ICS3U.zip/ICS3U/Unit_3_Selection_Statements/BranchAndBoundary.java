/**
 * Here's a program that gives the user discounts if they spend lots of
 * money and if they are young. It's supposed to give discounts if you spend
 * MORE THAN $1000, and if you are YOUNGER THAN 17. 
 * 
 * Write a flow chart for this program, then write branch and boundary test 
 * cases for this program. For each test case, specify the inputs, and what 
 * you expect to happen in each case. Make sure your test cases cover all 
 * important boundaries and all paths through the program. Then run the test
 * cases to see if you can find any errors, and fix the errors.
 * 
 * To hand in: flow chart, list of test cases, fixed code.
 * 
 * You can work with a partner on this.
 * 
 * November 15, 2010.
 * 
 * @author Sam Scott
 **/

package ExampleCode; 

import hsa_ufa.Console; 
import java.awt.*;      

public class BranchAndBoundary 
{
  static Console c = new Console(); 
  
  public static void main(String[] args) throws InterruptedException
  {
    c.print("Hi there. Welcome to the store.\nHow much money are you packing? ");
    double money = c.readDouble();
    if (money >= 1000)
      c.println("Hey, if you spend more than $1000 today, you qualify for a special discount!");
    
    c.print("How old are you? ");
    int age = c.readInt();
    
    if (age <=16)
      c.println("Lucky you! Everyone under 17 also qualifies for a special youth discount!");
    
    c.println("OK, how much are you spending?");
    double amountSpent = c.readDouble();
    
    if (amountSpent > money)
      c.println("Hey! You don't have that much. Nice try.");
    
    double discount = 0;
    
    if (amountSpent <= 1000)
      c.println("You're cheap.");
    else
    {
      c.println("You get a 10% big spender discount.");
      discount = discount + amountSpent*0.1;
    }
    
    if (age < 16)
    {
      c.println("You also get a 5% youth discount.");
      discount = discount + amountSpent*0.5;
    }
    
    if (discount == 0)
      c.println("Sorry, no discounts.");
    else
    {
      c.print("Your discount is $");
      c.print(discount,1,2);
      c.println(".");
    }
    c.print("And that makes your grand total $");
    c.print(amountSpent - discount,1,2);
    c.println(".");
    
    c.println("Have a nice day");
  }
}