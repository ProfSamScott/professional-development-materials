/**
 * An example of good internal documentation using an if statement.
 * October 21, 2007. 
 * @author Sam Scott
 **/
package ExampleCode;

import java.awt.*;
import hsa_ufa.Console;

public class GoodInternalDocumentation
{
  static Console c = new Console();           // The output console
  
  public static void main (String[] args) throws InterruptedException
  {
    
    // VARIABLES
    int income; // stores the income of the user
    
    // INPUT
    c.print ("Enter your pay: ");
    income = c.readInt ();
    
    // PROCESSING AND OUTPUT
    if (income > 100000)    // is the user rich?
    {
      c.println ("You are rich.");
      Thread.sleep (1000);
      c.println ("You owe lots of taxes");
    }
    else
    {
      c.println ("You are not rich.");
      Thread.sleep (1000);
      c.println ("Too bad for you.");
    }
  }
}
