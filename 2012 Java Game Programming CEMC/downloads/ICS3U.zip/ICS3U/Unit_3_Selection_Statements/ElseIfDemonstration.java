/**
 * This class demonstrates how you can string together if.. else if.. else if..
 * to implement the OneOfMany design pattern. The program is functionally identical
 * to the SwitchDemonstration program. November 16, 2010.
 * 
 * One advantage of this implementation is that you can use it with Strings.
 * 
 * @author Sam Scott
 **/
package ExampleCode;

import java.awt.*;
import hsa_ufa.Console;

public class ElseIfDemonstration
{
  static Console c;           // The output console
  
  /**
   * @param args unused
   **/
  public static void main (String[] args)
  {
    c = new Console ();
    
    int userInput; // variable for user input
    
    // Print the menu and get input
    c.println ("What would you like to do?");
    c.println ("1 = print a gray square");
    c.println ("2 = print a green circle");
    c.println ("3 = print a blue star");
    c.println ("4 = print a magenta maple leaf");
    userInput = c.readInt ();
    
    // Decide what to do based on the user input
    
    if (userInput == 1)          // user entered 1
    {
        c.setColor (Color.gray);
        c.drawRect (200, 200, 100, 100);
    }
    else if (userInput == 2)     // user entered 2
    {
        c.setColor(Color.green);
        c.drawOval (200, 200, 100, 100);
    } 
    else if (userInput == 3)     // user entered 3
    {
        c.setColor(Color.blue);
        c.drawStar (200, 200, 100, 100);
    }
    else if (userInput == 4)     // user entered 4
    {
        c.setColor(Color.magenta);
        c.drawMapleLeaf (200, 200, 100, 100);
    }
    else // DEFAULT CASE - optional
    { 
        c.setColor (Color.red);
        c.setFont (new Font ("SansSerif", Font.BOLD, 16));
        c.drawString ("You didn't follow the instructions!", 200, 200);
    }
    c.setColor(Color.black);
    c.drawString("Bye bye!",0, 350);
  } 
} 
