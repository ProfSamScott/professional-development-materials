/**
 * This is a souped-up version of the classic "Hello World" program
 *
 * @author Sam Scott
 **/
package ExampleCode;
import java.awt.*;
import hsa_ufa.Console;

public class HelloWorld
{
  // STEP 1
  // Create a new console 700 pixels wide, 500 pixels high, 
  // font size 14, title set to "Hello World Window"
  static Console c = new Console ("Hello World Window");
  
  public static void main (String[] args) throws InterruptedException
  {
    // STEP 2
    // Print the hello world message in two parts
    c.setColor(Color.RED);
    c.print("Hello ");
    Thread.sleep(1000); // pause 1 second
    c.setColor(Color.WHITE);
    c.setBackgroundColor(new Color(128,128,128));
    c.print("WORLD!!!");
    
    // STEP 3
    // Print another message
    Thread.sleep(1000);
    c.setColor(Color.MAGENTA);
    c.setBackgroundColor(Color.WHITE);
    c.println();
    c.println();
    c.println("I Love It Here!!!");
    
    // STEP 4
    // Print a message in the middle of the screen
    Thread.sleep(1000);
    c.setCursor(10,50);
    c.println("Now I'm over here!");
    
  } // main method
} // HelloWorld class
