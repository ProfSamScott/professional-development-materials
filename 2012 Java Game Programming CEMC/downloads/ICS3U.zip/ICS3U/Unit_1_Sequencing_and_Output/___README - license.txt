The documents in this archive are all copyright Sam Scott, 2012. 

Downloaders are granted permission to modify and distribute for educational purposes only.

sam.scott@sheridanc.on.ca