/**
 * This program demonstrates the use of Thread.sleep() to make
 * text blink on the screen.  September 12, 2007.
 *
 * @author Sam Scott
 **/
package ExampleCode;

import java.awt.*;
import hsa_ufa.Console;

public class VirusAlert
{
  static Console c = new Console (150, 100, 12, "Virus Alert");     // The output console
  
  /**
   * @param args Unused
   **/
  public static void main (String[] args) throws InterruptedException
  {
    
    c.setColor (Color.red);
    
    // This block of code repeats to make the message blink
    c.setCursor (2, 3);
    c.println ("Virus Alert!");
    Thread.sleep (500);
    c.clear ();
    Thread.sleep (500);
    // End of repeated block
    c.setCursor (2, 3);
    c.println ("Virus Alert!");
    Thread.sleep (500);
    c.clear ();
    Thread.sleep (500);
    
    c.setCursor (2, 3);
    c.println ("Virus Alert!");
    Thread.sleep (500);
    c.clear ();
    Thread.sleep (500);
    
    c.setCursor (2, 3);
    c.println ("Virus Alert!");
    Thread.sleep (500);
    c.clear ();
    Thread.sleep (500);
    
    c.setCursor (2, 3);
    c.println ("Virus Alert!");
    Thread.sleep (500);
    c.clear ();
    Thread.sleep (500);
    
    // Now close the console window
    c.close ();
  } 
} 
