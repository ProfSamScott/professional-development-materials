
/**
 * A "hello world" program
 * @author Sam Scott
 **/
package ExampleCode;

import java.awt.*;
import hsa_ufa.Console;

public class HelloWorld3
{
  static Console c;
  
  public static void main (String[] args) throws InterruptedException
  {
    c = new Console (300,300,14,"Hello World Window");
    
    c.setColor(Color.RED);
    c.print("Hello ");
    Thread.sleep(1000);
    c.setColor(Color.WHITE);
    c.setBackgroundColor(new Color(128,128,128));
    c.print("WORLD!!!");
  }
}